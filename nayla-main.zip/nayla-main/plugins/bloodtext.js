let fetch = require('node-fetch');
let ftype = require('file-type');
let { getBuffer, succes } = require('../lib/functions.js');

let handler = async(m, { conn, text }) => {

    if (!text) return conn.reply(m.chat, 'Silahkan masukan teksnya', m)

  await conn.reply(m.chat, mess.wait, 0, { thumbnail: await(await fetch(ext.thum)).buffer(), contextInfo: {
                  externalAdReply: {
                    mediaUrl: 'https://youtu.be/-tKVN2mAKRI',
                    title: ext.title,
                    body: ext.body,
                    thumbnail: await(await fetch(ext.thum)).buffer()
                   }
                 }
               }
           )

  let hasil = await (await fetch('http://lolhuman.herokuapp.com/api/textprome/bloodfrosted?apikey=31caf10e4a64e86c1a92bcba&text=' + text)).buffer()

     conn.sendFile(m.chat, hasil, 'foto.jpg', mess.sukses, m)
}
handler.help = ['bloodtext <teks>']
handler.tags = ['sticker']
handler.command = /^(bloodtext)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.exp = 0
handler.limit = true

module.exports = handler
